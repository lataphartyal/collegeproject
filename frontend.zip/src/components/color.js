import React from "react";

const color = () => {
  return (
    <>
      <ul className="colors ps-0">
        <li></li>
        <li></li>
        <li></li>
        <li></li>
      </ul>
    </>
  );
};

export default color;
