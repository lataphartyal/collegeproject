const services = [
  {
    title: "Free Shipping",
    tagline: "From all orders over $5",
    image: "images/service.png",
  },
  {
    title: "Daily Surprise Offers",
    tagline: "From all orders over $5",
    image: "images/service.png",
  },
  {
    title: "Free Shipping", 
    tagline: "From all orders over $5",
    image: "images/service.png",
  },
  {
    title: "Free Shipping",
    tagline: "From all orders over $5",
    image: "images/service.png",
  },
  {
    title: "Free Shipping",
    tagline: "From all orders over $5",
    image: "images/service.png",
  },
];
